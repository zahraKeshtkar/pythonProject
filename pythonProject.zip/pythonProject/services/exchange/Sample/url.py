class UrlMixin:
    LOGIN = "/tokens"
    SETTLE_WITH_EXCHANGE = "/settle"
